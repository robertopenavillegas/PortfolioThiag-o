import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage {

    opcaoEscolhida =  '';
    pontuacaoUsuario = 0;
    pontuacaoComputador = 0;
    resultado = '';
  
  constructor() {}

  jogar() {

    const opcoes = ['Pedra', 'Papel', 'Tesoura'];

    let opcaoUsuario = parseInt(this.opcaoEscolhida);

    let opcaoComputador = Math.floor(Math.random() * 3) + 1;

    let opcaoUsuarioString = opcoes[opcaoUsuario - 1];

    let opcaoComputadorString = opcoes[opcaoComputador -1];

    if (opcaoUsuario === opcaoComputador) {
        this.resultado = 'Empate';
    } else if (
        (opcaoUsuarioString === 'Pedra' && opcaoComputadorString === 'Tesoura') || 
        (opcaoUsuarioString === 'Papel' && opcaoComputadorString === 'Pedra') || 
        (opcaoUsuarioString === 'Tesoura' && opcaoComputadorString === 'Papel')   
    ) {
        this.resultado = 'Você venceu: sua escolha:' + opcaoUsuarioString + ' escolha Computador:' + opcaoComputadorString ;
        this.pontuacaoUsuario++;

    } else {
        this.resultado = 'Computador Venceu: sua escolha:' + opcaoUsuarioString + ' escolha Computador:' + opcaoComputadorString;
        this.pontuacaoComputador++;
    }


  }
}
